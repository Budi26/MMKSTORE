package project.mmkstore.mmkstore.setting


import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.app.AppCompatDelegate
import project.mmkstore.mmkstore.databinding.ActivitySettingBinding

// ...


class SettingActivity : AppCompatActivity() {

    private lateinit var binding: ActivitySettingBinding
    private lateinit var themePreferences: ThemePreferences


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivitySettingBinding.inflate(layoutInflater)
        setContentView(binding.root)

        themePreferences = ThemePreferences(this)

        // Inisialisasi SwitchMaterial
        val switchTheme = binding.switchTheme
        switchTheme.isChecked = themePreferences.isDarkTheme()

        switchTheme.setOnCheckedChangeListener { _, isChecked ->

            themePreferences.setDarkTheme(isChecked)
            // Terapkan perubahan tema ke seluruh aplikasi
            // Terapkan perubahan tema ke seluruh aplikasi
            recreate()


            applyTheme(isChecked)
        }

    }

    /*viewModel.getTheme().observe(this) { it ->
            if (it) {
                binding.switchTheme.text = "Dark Theme"
                AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES)
            } else {
                binding.switchTheme.text = "Light Theme"
                AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO)
            }
            binding.switchTheme.isChecked = it
        }
        binding.switchTheme.setOnCheckedChangeListener { _, isChecked ->
            viewModel.saveTheme(isChecked)
        }*/


    // Metode untuk menerapkan tema sesuai preferensi
    private fun applyTheme(isDarkMode: Boolean) {
        if (isDarkMode) {
            AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES)
        } else {
            AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO)
        }
    }


    /*override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menuInflater.inflate(R.menu.option_menu, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when (item.itemId) {
            android.R.id.home -> {
                onBackPressed()
                return true
            }
            R.id.favorite_menu -> {
                Intent(this, FavoriteActivity::class.java).also {
                    startActivity(it)
                }
                return true
            }
            else -> return super.onOptionsItemSelected(item)
        }
    }*/
}


