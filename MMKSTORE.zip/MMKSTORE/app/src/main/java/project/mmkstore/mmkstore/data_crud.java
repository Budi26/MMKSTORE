package project.mmkstore.mmkstore;

public class data_crud {
    private String code;
    private String name;
    private String brand;
    private String type;
    private String hasilgol;
    private String gender;
    private String tgllahir;
    private String nohp;
    private String dataemail;
    private String price;

    private String address;
    private String gambar;
    private String key;

    public data_crud() {
    }

    public data_crud(String code, String name, String brand, String type, String hasilgol, String gender, String tgllahir, String nohp, String dataemail, String price, String address, String gambar) {
        this.code = code;
        this.name = name;
        this.brand = brand;
        this.type = type;
        this.hasilgol = hasilgol;
        this.gender = gender;
        this.tgllahir = tgllahir;
        this.nohp = nohp;
        this.dataemail = dataemail;
        this.price = price;
        this.address = address;
        this.gambar = gambar;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getBrand() {
        return brand;
    }

    public void setBrand(String brand) {
        this.brand = brand;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getHasilgol() {
        return hasilgol;
    }

    public void setHasilgol(String hasilgol) {
        this.hasilgol = hasilgol;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public String getTgllahir() {
        return tgllahir;
    }

    public void setTgllahir(String tgllahir) {
        this.tgllahir = tgllahir;
    }

    public String getNohp() {
        return nohp;
    }

    public void setNohp(String nohp) {
        this.nohp = nohp;
    }

    public String getDataemail() {
        return dataemail;
    }

    public void setDataemail(String dataemail) {
        this.dataemail = dataemail;
    }

    public String getPrice() {
        return price;
    }

    public void setPrice(String price) {
        this.price = price;
    }

    public String getGambar() {
        return gambar;
    }

    public void setGambar(String gambar) {
        this.gambar = gambar;
    }

    public String getKey() {
        return key;
    }

    public void setKey(String key) {
        this.key = key;
    }
}
