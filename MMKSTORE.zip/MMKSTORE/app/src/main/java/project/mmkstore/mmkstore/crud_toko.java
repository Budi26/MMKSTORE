package project.mmkstore.mmkstore;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class crud_toko extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_crud_toko);


    }
}