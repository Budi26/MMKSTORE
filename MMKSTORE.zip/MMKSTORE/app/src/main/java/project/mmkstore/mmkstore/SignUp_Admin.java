package project.mmkstore.mmkstore;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.FirebaseDatabase;

public class SignUp_Admin extends AppCompatActivity {
    private EditText signup_name, signup_email, signup_password, signup_confirm_password;
    private Button signup;
    private TextView signup_login;
    private FirebaseAuth auth;
    private String getName, getEmail, getPassword, getConfirmPassword;
    private ProgressBar progressBar;


    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_up_admin);

        signup_name=findViewById(R.id.signup_name_admin);
        signup_email=findViewById(R.id.signup_email_admin);
        signup_password=findViewById(R.id.signup_password_admin);
        signup_confirm_password=findViewById(R.id.signup_confirm_password_admin);
        signup=findViewById(R.id.signup_admin);
        signup_login=findViewById(R.id.signup_login_admin);
        progressBar=findViewById(R.id.pro_signup_admin);
        progressBar.setVisibility(View.GONE);
        auth=FirebaseAuth.getInstance();




        signup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                progressBar.setVisibility(View.VISIBLE);
                startActivity(new Intent(SignUp_Admin.this, Login_Admin.class));
                cekDataUser();

            }


            private void cekDataUser() {
                getName=signup_name.getText().toString();
                getEmail=signup_email.getText().toString();
                getPassword=signup_password.getText().toString();
                getConfirmPassword=signup_confirm_password.getText().toString();

                if(TextUtils.isEmpty(getName)|| TextUtils.isEmpty(getEmail)|| TextUtils.isEmpty(getPassword))
                {
                    Toast.makeText(SignUp_Admin.this, "Nama, Email, Dan Password tidak boleh kosong", Toast.LENGTH_SHORT).show();
                }
                else{
                    if(getPassword.length()<6)
                    {
                        Toast.makeText(SignUp_Admin.this, "Password Terlalu Lemah", Toast.LENGTH_SHORT).show();
                    }
                    else{
                        createUserAccount();
                    }
                }


            }

            private void createUserAccount() {
                auth.createUserWithEmailAndPassword(getEmail,getPassword).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        Pengguna_Admin pemilik = new Pengguna_Admin (getEmail,getPassword);
                        FirebaseDatabase.getInstance().getReference("Pemilik").setValue(pemilik).addOnCompleteListener(new OnCompleteListener<Void>() {
                            @Override
                            public void onComplete(@NonNull Task<Void> task) {
                                if(task.isSuccessful()){
                                    progressBar.setVisibility(View.GONE);
                                    auth.getCurrentUser().sendEmailVerification().addOnCompleteListener(new OnCompleteListener<Void>() {
                                        @Override
                                        public void onComplete(@NonNull Task<Void> task) {
                                            if(task.isSuccessful()){
                                                Toast.makeText(SignUp_Admin.this, "Registration Succsessfully !!, Please Check your Email for verification", Toast.LENGTH_SHORT).show();
                                                startActivity(new Intent(SignUp_Admin.this,Login_Admin.class));
                                                finish();

                                            }else {
                                                Toast.makeText(SignUp_Admin.this, task.getException().getMessage(), Toast.LENGTH_SHORT).show();

                                            }
                                        }
                                    });
                                } else {
                                    progressBar.setVisibility(View.GONE);
                                    Toast.makeText(SignUp_Admin.this,task.getException().getMessage(), Toast.LENGTH_SHORT).show();
                                }
                            }
                        }).addOnFailureListener(new OnFailureListener() {
                            @Override
                            public void onFailure(@NonNull Exception e) {
                                progressBar.setVisibility(View.GONE);
                                Toast.makeText(SignUp_Admin.this, e.getMessage(), Toast.LENGTH_SHORT).show();
                                finish();
                            }
                        });
                    }
                }).addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        progressBar.setVisibility(View.GONE);
                        Toast.makeText(SignUp_Admin.this, e.getMessage(), Toast.LENGTH_SHORT).show();
                        finish();
                    }
                });







            }

        });

        signup_login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(SignUp_Admin.this, Login_Admin.class));

            }
        });
    }
}