package project.mmkstore.mmkstore;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

public class Login_Admin extends AppCompatActivity {


    private EditText login_email, login_password;
    TextView register,forgot,backuser;
    private Button login;
    private FirebaseAuth firebaseAuth;
    private FirebaseAuth.AuthStateListener Listener;
    private String getEmail, getPassword;
    private ProgressBar progressBar;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login_admin);
        login_email=findViewById(R.id.login_email_admin);
        login_password=findViewById(R.id.login_password_admin);
        login=findViewById(R.id.login_admin);
        progressBar=findViewById(R.id.prog_login_admin);
        progressBar.setVisibility(View.GONE);
        register=findViewById(R.id.register_admin);
        forgot=findViewById(R.id.forgot_password_admin);
        backuser=findViewById(R.id.backuser);

        firebaseAuth = FirebaseAuth.getInstance();
        final SharedPreferences[] sharedPreferences = new SharedPreferences[1];


        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String email = login_email.getText().toString().trim();
                String password = login_password.getText().toString().trim();

                // Memeriksa apakah email dan password tidak kosong
                if (TextUtils.isEmpty(email) || TextUtils.isEmpty(password)) {
                    Toast.makeText(Login_Admin.this, "Email atau Password tidak boleh kosong", Toast.LENGTH_SHORT).show();
                } else {
                    // Login menggunakan Firebase Authentication
                    firebaseAuth.signInWithEmailAndPassword(email, password)
                            .addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                                @Override
                                public void onComplete(@NonNull Task<AuthResult> task) {
                                    if (task.isSuccessful()) {
                                        // Login berhasil
                                        FirebaseUser currentUser = firebaseAuth.getCurrentUser();
                                        if (currentUser != null) {
                                            // Memeriksa apakah pengguna yang berhasil login adalah admin
                                            if (currentUser.getEmail().equals("budinurohman96@gmail.com")) {
                                                Toast.makeText(Login_Admin.this, "Selamat Datang Di Admin!", Toast.LENGTH_SHORT).show();
                                                // Simpan status login pengguna ke SharedPreferences
                                                sharedPreferences[0] = getSharedPreferences("loginStatus", MODE_PRIVATE);
                                                SharedPreferences.Editor editor = sharedPreferences[0].edit();
                                                editor.putBoolean("isLoggedIn", true);
                                                editor.apply();

                                                Intent intent = new Intent(Login_Admin.this, Admin.class);
                                                startActivity(intent);
                                                finish();
                                            } else {
                                                // Bukan admin, mencegah akses
                                                firebaseAuth.signOut();
                                                Toast.makeText(Login_Admin.this, "Anda Bukan Admin MMK STORE", Toast.LENGTH_SHORT).show();
                                            }
                                        }
                                    } else {
                                        // Login gagal
                                        Toast.makeText(Login_Admin.this, "Login Gagal. Silahkan Coba Lagi.", Toast.LENGTH_SHORT).show();
                                    }
                                }
                            });
                }
            }
        });
        // Pemeriksaan status login saat aplikasi dimulai
        sharedPreferences[0] = getSharedPreferences("loginStatus", MODE_PRIVATE);
        boolean isLoggedIn = sharedPreferences[0].getBoolean("isLoggedIn", false);

        if (isLoggedIn) {
            // Jika pengguna sudah login sebelumnya, arahkan mereka ke halaman Admin
            Intent intent = new Intent(Login_Admin.this, Admin.class);
            startActivity(intent);
            finish(); // Selesaikan activity saat pindah ke halaman Admin
        }




        /*auth=FirebaseAuth.getInstance();

        Listener = new  FirebaseAuth.AuthStateListener() {
            @Override
            public void onAuthStateChanged(@NonNull FirebaseAuth firebaseAuth) {
                FirebaseUser Pemilik = firebaseAuth.getCurrentUser();
                if (Pemilik != null && Pemilik.isEmailVerified()){
                    startActivity(new Intent(Login_Admin.this,Admin.class));
                    finish();
                }
            }
        };*/









        /*login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                progressBar.setVisibility(View.VISIBLE);
                getEmail = login_email.getText().toString();
                getPassword = login_password.getText().toString();
                if (TextUtils.isEmpty(getEmail) || TextUtils.isEmpty(getPassword)){
                    Toast.makeText(Login_Admin.this, "Email atau Password tidak boleh kosong", Toast.LENGTH_SHORT).show();
                } else {
                    loginUserAccount();
                }
                startActivity(new Intent(Login_Admin.this, Admin.class));

            }

        });*/



        register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(Login_Admin.this, SignUp_Admin.class));

            }
        });

        backuser.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(Login_Admin.this, Dashboard.class));

            }
        });

        /*login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(Login_Admin.this, Admin.class));
            }
        });*/




        forgot.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(Login_Admin.this, ForgotPassword_Admin.class));

            }
        });



    }
    /*private void loginadmin(){
        String email = login_email.getText().toString().trim();
        String password = login_password.getText().toString().trim();
        firebaseAuth.signInWithEmailAndPassword(email, password)
                .addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if (task.isSuccessful()) {
                            // Login berhasil
                            FirebaseUser currentUser = firebaseAuth.getCurrentUser();
                            if (currentUser != null) {
                                // Memeriksa apakah pengguna yang berhasil login adalah admin
                                if (currentUser.getEmail().equals("budinurohman96@gmail.com")) {
                                    Toast.makeText(Login_Admin.this, "Selamat Datang Di Admin!", Toast.LENGTH_SHORT).show();
                                    Intent intent = new Intent(Login_Admin.this,Admin.class);
                                    startActivity(intent);
                                } else {
                                    // Bukan admin, mencegah akses
                                    firebaseAuth.signOut();
                                    Toast.makeText(Login_Admin.this, "Anda Bukan Admin MMK STORE", Toast.LENGTH_SHORT).show();
                                }
                            }
                        } else {
                            // Login gagal
                            Toast.makeText(Login_Admin.this, "Login failed. Please try again.", Toast.LENGTH_SHORT).show();
                        }
                    }
                });
    }
    @Override
    protected void onStart() {

        super.onStart();
        firebaseAuth.addAuthStateListener(Listener);
    }

    @Override
    protected void onStop() {

        super.onStop();
        if (Listener != null){
            firebaseAuth.removeAuthStateListener(Listener);
        }
    }
    private void loginUserAccount() {
        firebaseAuth.signInWithEmailAndPassword(getEmail, getPassword).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
            @Override
            public void onComplete(@NonNull Task<AuthResult> task) {
                if (task.isSuccessful()){
                    progressBar.setVisibility(View.GONE);
                    if (firebaseAuth.getCurrentUser().isEmailVerified()){
                        Toast.makeText(Login_Admin.this, "Login Successfully", Toast.LENGTH_SHORT).show();
                        Intent intent = new Intent(Login_Admin.this,Admin.class);
                        startActivity(intent);
                    } else {
                        AlertDialog.Builder alert = new AlertDialog.Builder(Login_Admin.this);
                        alert.setTitle("Periksa Email Anda Untuk Verifikasi");
                        alert.setNeutralButton("OK", new
                                DialogInterface.OnClickListener() {
                                    @Override
                                    public void onClick(DialogInterface dialog, int which){
                                        return;
                                    }
                                });
                        alert.create();
                        alert.show();
                    }
                } else {
                    progressBar.setVisibility(View.GONE);
                    Toast.makeText(Login_Admin.this,task.getException().getMessage(), Toast.LENGTH_SHORT).show();
                }
            }
        });
    }*/
}