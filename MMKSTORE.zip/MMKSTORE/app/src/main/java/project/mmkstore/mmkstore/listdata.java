package project.mmkstore.mmkstore;

import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.MenuItem;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AppCompatDelegate;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.viewpager2.widget.ViewPager2;

import com.google.android.gms.ads.AdView;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import project.mmkstore.mmkstore.setting.SessionManager;
import project.mmkstore.mmkstore.setting.ThemePreferences;

public class listdata extends AppCompatActivity implements RecyclerViewAdapter.dataListener {

    private  RecyclerView recyclerView;
    RecyclerViewAdapter adapter;
    private RecyclerView.LayoutManager layoutManager;

    private DatabaseReference reference;
    private ArrayList<data_crud> data_crud;

    private FloatingActionButton fab, home;

    private EditText searchView;
    private ViewPager2 viewPager;
    private SliderAdapter sliderAdapter;
    private SessionManager sessionManager;

    BottomNavigationView bottomNavigationView;
    private AdView mAdView;

    public listdata() {
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setThemeFromPreferences();
        setContentView(R.layout.activity_ui);
        sessionManager = new SessionManager(this);

//        MobileAds.initialize(this, new OnInitializationCompleteListener() {
//            @Override
//            public void onInitializationComplete(InitializationStatus initializationStatus) {
//            }
//        });
//
//        mAdView = findViewById(R.id.adView);
//        AdRequest adRequest = new AdRequest.Builder().build();
//        mAdView.loadAd(adRequest);

        /*Button beli = findViewById(R.id.beli1);
        beli.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(listdata.this, Chekout.class));
            }
        });*/

        recyclerView = findViewById(R.id.datalist_toko);
        //fab = findViewById(R.id.fab);
        /*home = findViewById(R.id.home1);*/
        ViewPager2 viewPager = findViewById(R.id.view_pager);
        SliderAdapter sliderAdapter = new SliderAdapter(this, new int[]{R.drawable.banner1, R.drawable.banner2,
                R.drawable.banner3, R.drawable.banner4, R.drawable.banner5, R.drawable.banner6});
        viewPager.setAdapter(sliderAdapter);



        bottomNavigationView = findViewById(R.id.nav_view);
        bottomNavigationView.setSelectedItemId(R.id.navigation_home);
        bottomNavigationView.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                switch (item.getItemId())
                {
                    case R.id.navigation_dashboard:
                        startActivity(new Intent(getApplicationContext(), Dashboard.class));
                        overridePendingTransition(0,0);
                        return true;
                    case R.id.navigation_home:


                        return true;
                    case R.id.navigation_cart:
                        startActivity(new Intent(getApplicationContext(), listdata_cart.class));
                        overridePendingTransition(0,0);


                        return true;
                }
                return false;
            }
        });




        //memanggil method GetData dari Firebase
        GetData("");

        searchView = findViewById(R.id.etcsearch);
        searchView.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                if (s.toString().isEmpty()) {
                    GetData(s.toString());
                } else {
                    adapter.getFilter().filter(s);
                }

            }

        });

        //memanggil method
        MyRecyclerView();

        /*fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(listdata.this, Chekout.class);
                startActivity(intent);
            }
        });*/

        /*home.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(listdata.this, MainActivity.class);
                startActivity(intent);
                finish();
            }
        });*/

    }
    private void setThemeFromPreferences() {
        ThemePreferences themePreferences = new ThemePreferences(this);
        if (themePreferences.isDarkTheme()) {
            AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES);
        } else {
            AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO);
        }
    }

    private List<Integer> getSliderImages() {
        List<Integer> images = new ArrayList<>();
        images.add(R.drawable.minyak);
        images.add(R.drawable.beras);
        images.add(R.drawable.gulapasir);
        return images;
    }

    private  void  GetData(String data) {
        reference = FirebaseDatabase.getInstance().getReference();
        reference.child("Admin").child("MMK STORE").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                data_crud = new ArrayList<>();
                data_crud.clear();
                for (DataSnapshot snapshot : dataSnapshot.getChildren()){
                data_crud Shoes = snapshot.getValue(project.mmkstore.mmkstore.data_crud.class);

                Shoes.setKey(snapshot.getKey());
                data_crud.add(Shoes);
                }
                // Balikkan urutan data agar data terbaru muncul di paling atas
                Collections.reverse(data_crud);

                adapter = new RecyclerViewAdapter(data_crud, listdata.this);
                adapter.notifyDataSetChanged();
                recyclerView.setAdapter(adapter);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

                Toast.makeText(getApplicationContext(), "Data gagal dimuat", Toast.LENGTH_SHORT).show();
                Log.e("MyListActivity", error.getDetails() + " " + error.getMessage());

            }

        });
    }
    private void MyRecyclerView(){
        layoutManager = new LinearLayoutManager(this);
        recyclerView.setLayoutManager(layoutManager);
        recyclerView.setHasFixedSize(true);

        //membuat underline pada setiap item dalam list
        DividerItemDecoration ItemDecoration = new DividerItemDecoration(getApplicationContext(), DividerItemDecoration.VERTICAL);
        ItemDecoration.setDrawable(ContextCompat.getDrawable(getApplicationContext(), R.drawable.line));
        recyclerView.addItemDecoration(ItemDecoration);
    }

    @Override
    public void onDelete(project.mmkstore.mmkstore.data_crud data, int position) {
        if (reference != null){
            reference.child("Admin")
                    .child("MMK STORE")
                    .child(data.getKey())
                    .removeValue()
                    .addOnSuccessListener(new OnSuccessListener<Void>() {
                        @Override
                        public void onSuccess(Void unused) {
                            Toast.makeText(listdata.this, "Data Berhasil di Hapus", Toast.LENGTH_SHORT).show();
                        }
                    });
        }
    }
}