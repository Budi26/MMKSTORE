package project.mmkstore.mmkstore;

import static android.text.TextUtils.isEmpty;

import android.app.DatePickerDialog;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.drawable.BitmapDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.OnProgressListener;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;

import java.io.ByteArrayOutputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.UUID;

public class CreateToko extends AppCompatActivity {
    ProgressBar progress;
    EditText code, name, tgllahir, nohp, email, price, address;
    Spinner brand, type;
    CheckBox golA, golB, golAB, golO;
    RadioGroup gender;
    TextView hasil;
    RadioButton jkRb;
    Button getfoto, showdata, save;
    ImageView foto;
    String getCode, getName, getBrand, getType, getAddress, getEmail, getGambar;
    String getTgllahir;
    String getNohp, getPrice, getGender, getHasilgol, outputGolongan;

    DatePickerDialog datePickerDialog;
    SimpleDateFormat simpleDateFormat;

    ArrayList<String> hasilgol;
    Uri url;
    Bitmap bitmap;

    DatabaseReference dbF;
    StorageReference dbS;

    private static final int REQUEST_CODE_CAMERA = 1;
    private static final int REQUEST_CODE_GALLERY = 2;
    BottomNavigationView bottomNavigationView;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create_toko);




        // variabel EditText ID
        code = findViewById(R.id.nama);
        name = findViewById(R.id.harga_barang);
        nohp = findViewById(R.id.stok_barang);

        /*brand = findViewById(R.id.brand);
        type = findViewById(R.id.type);
        tgllahir = findViewById(R.id.datebirth);
        price = findViewById(R.id.price);
        address = findViewById(R.id.address);

        //variabel CheckBox ID
        golA = findViewById(R.id.golA);
        golB = findViewById(R.id.golB);
        golAB = findViewById(R.id.golAB);
        golO = findViewById(R.id.golO);

        //variabel TextView ID
        hasil = findViewById(R.id.hasil);

        //variabel RdGroup & RdButton ID
        gender = findViewById(R.id.gender); */

        //variabel ImageView ID
        foto = findViewById(R.id.barang);

        //variabel Button ID
        getfoto = findViewById(R.id.getfoto_toko);
        save = findViewById(R.id.save_toko);
        showdata = findViewById(R.id.showdata_toko);

        //variabel ProgressBar ID
        progress = findViewById(R.id.progress_toko);
        progress.setVisibility(View.GONE);





        /*simpleDateFormat = new SimpleDateFormat("dd MM yyy");
        tgllahir.setOnClickListener(view -> {
            showDataDialog();
        });

        golA.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                if (true) {
                    golB.setChecked(false);
                    golAB.setChecked(false);
                    golO.setChecked(false);
                    outputGolongan = "A";
                }
            }
        });

        golB.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                if (true) {
                    golA.setChecked(false);
                    golAB.setChecked(false);
                    golO.setChecked(false);
                    outputGolongan = "B";
                }
            }
        });

        golAB.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                if (true) {
                    golA.setChecked(false);
                    golB.setChecked(false);
                    golO.setChecked(false);
                    outputGolongan = "AB";
                }
            }
        });

        golO.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                if (true) {
                    golB.setChecked(false);
                    golAB.setChecked(false);
                    golA.setChecked(false);
                    outputGolongan = "O";
                }
            }
        });*/

        //mendapatkan referensi dari DataBase storage
        dbS = FirebaseStorage.getInstance().getReference();

        //mendapatkan Referensi dari DataBase Firebase
        dbF = FirebaseDatabase.getInstance().getReference();

        save.setOnClickListener(view -> {
            getCode = code.getText().toString();
            getName = name.getText().toString();
            getNohp = nohp.getText().toString();
            //getEmail = email.getText().toString();
            /*getBrand = brand.getSelectedItem().toString();
            getType = type.getSelectedItem().toString();
            if (outputGolongan == null){
                getHasilgol = null;
            } else {
                getHasilgol = outputGolongan.trim();
            }
            if (jkRb == null){
                getGender = null;
            } else {
                getGender = jkRb.getText().toString();
            }
            getTgllahir = tgllahir.getText().toString();
            getNohp = nohp.getText().toString();
            getEmail = email.getText().toString();
            getPrice = price.getText().toString();
            getAddress = address.getText().toString();*/
            getGambar = foto.toString().trim();

            checkUser();

        });

        showdata.setOnClickListener(view -> {
            onBackPressed();
        });

        getfoto.setOnClickListener(view -> {
            getImage();
        });




    }
    //Tanggal
    /*private void showDataDialog(){
        Calendar calendar = Calendar.getInstance();
        datePickerDialog = new DatePickerDialog(this, new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker view, int year, int month, int dayOfYear) {
                Calendar newCalendar = Calendar.getInstance();
                newCalendar.set(year, month, dayOfYear);
                tgllahir.setText(simpleDateFormat.format(newCalendar.getTime()));
            }
        }, calendar.get(Calendar.YEAR), calendar.get(Calendar.MONTH), calendar.get(calendar.DAY_OF_YEAR));
        datePickerDialog.show();
    }*/

    private  void getImage(){
        Intent imageIntentGallery = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
        startActivityForResult(imageIntentGallery, 2);
    }
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data){
        super.onActivityResult(requestCode, resultCode, data);
        //menghapus hasil data yang diambil dari kamera atau galeri pada imageView
        switch (requestCode){
            case REQUEST_CODE_CAMERA:
                if (resultCode==RESULT_OK){
                    foto.setVisibility(View.VISIBLE);
                    Bitmap btmp = (Bitmap) data.getExtras().get("data");
                    foto.setImageBitmap(btmp);
                }
                break;
            case REQUEST_CODE_GALLERY:
                if (resultCode==RESULT_OK) {
                    foto.setVisibility(View.VISIBLE);
                    url = data.getData();
                    foto.setImageURI(url);
                } break;
        }
    }

    //Cek User Input + Push data
    private void checkUser(){
        //mengecek apakah ada data yang kosong
        if(isEmpty(getCode) || isEmpty(getName) || isEmpty(getNohp) /*|| isEmpty(getEmail) || isEmpty(getBrand) || isEmpty(getType) ||
                isEmpty(getAddress) || isEmpty(getHasilgol) || outputGolongan.equals("") ||
                outputGolongan==null || isEmpty(getPrice) || isEmpty(getGender)  ||
                isEmpty(getTgllahir) */ || url == null){
            //Jika ada, maka akan menampilkan pesan singkat
            Toast.makeText(CreateToko.this, "Data Tidak Boleh Ada Yang Kosong", Toast.LENGTH_SHORT).show();
        } else {
            //Jika tidak ada yang kosong maka akan melakukan fungsi berikut
            foto.setDrawingCacheEnabled(true);
            foto.buildDrawingCache();
            Bitmap bitmap = ((BitmapDrawable) foto.getDrawable()).getBitmap();
            ByteArrayOutputStream stream = new ByteArrayOutputStream();

            //Mengkompres bitmap menjadi JPG dengan kualitas gambar 100%
            bitmap.compress(Bitmap.CompressFormat.JPEG, 100, stream);
            byte[] bytes = stream.toByteArray();

            //Lokasi lengkap dimana gambar akan disimpan
            String namafile = UUID.randomUUID()+".jpg";
            final String pathImage = "gambar/"+namafile;
            UploadTask uploadTask = dbS.child(pathImage).putBytes(bytes);
            uploadTask.addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
                @Override
                public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {
                    taskSnapshot.getStorage().getDownloadUrl().addOnSuccessListener(new OnSuccessListener<Uri>() {
                        @Override
                        public void onSuccess(Uri uri) {
                            dbF.child("Admin").child("MMK STORE").push().setValue(new data_crud(getCode, getName, getBrand,
                                    getType, getHasilgol, getGender, getTgllahir, getNohp, getEmail, getPrice,getAddress, uri.toString().trim()
                            )).addOnCompleteListener(new OnCompleteListener<Void>() {
                                @Override
                                public void onComplete(@NonNull Task<Void> task) {
                                    //hal ini terjadi saar user berhasil menyimpan datanya kedalam database
                                    code.setText("");
                                    name.setText("");
                                    nohp.setText("");


                                    Toast.makeText(CreateToko.this, "Data Berhasil Tersimpan", Toast.LENGTH_SHORT).show();
                                    progress.setVisibility(View.VISIBLE);
                                    startActivity(new Intent(CreateToko.this, Listdata_Admin.class));
                                    finish();

                                }
                            });
                            //Jika tidak ada maka dapat diproses dan menyimpan pada database
                            //menyimpan data referensi pada database berdasarkan User ID dari masing-masing akun
                        }
                    });
                }
            }).addOnFailureListener(new OnFailureListener() {
                @Override
                public void onFailure(@NonNull Exception e) {
                    progress.setVisibility(View.GONE);
                    Toast.makeText(CreateToko.this, "Upload Gagal", Toast.LENGTH_SHORT).show();
                }
            }).addOnProgressListener(new OnProgressListener<UploadTask.TaskSnapshot>() {
                @Override
                public void onProgress(@NonNull UploadTask.TaskSnapshot snapshot) {
                    progress.setVisibility(View.VISIBLE);
                    double progres = (100.0 * snapshot.getBytesTransferred()) / snapshot.getTotalByteCount();
                    progress.setProgress((int) progres);
                }
            });

        }
    }
    //Fungsi RadioButton
    /*public void rbclick(View v){
        int radiobuttonid = gender.getCheckedRadioButtonId();
        jkRb = (RadioButton) findViewById(radiobuttonid);
    }*/


}