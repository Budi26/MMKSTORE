package project.mmkstore.mmkstore;

import android.annotation.SuppressLint;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

public class Login extends AppCompatActivity {


    private EditText login_email, login_password;
    TextView register,forgot;
    private Button login;
    private FirebaseAuth auth;
    private FirebaseAuth.AuthStateListener Listener;
    private String getEmail, getPassword;
    private ProgressBar progressBar;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        login_email=findViewById(R.id.login_email);
        login_password=findViewById(R.id.login_password);
        login=findViewById(R.id.login);
        progressBar=findViewById(R.id.prog_login);
        progressBar.setVisibility(View.GONE);
        register=findViewById(R.id.register);
        forgot=findViewById(R.id.forgot_password);


        auth=FirebaseAuth.getInstance();

        Listener = new FirebaseAuth.AuthStateListener() {
            @Override
            public void onAuthStateChanged(@NonNull FirebaseAuth firebaseAuth) {
                FirebaseUser user = firebaseAuth.getCurrentUser();
                if (user != null && user.isEmailVerified()){
                    startActivity(new Intent(Login.this,listdata.class));
                    finish();
                }
            }
        };









        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                progressBar.setVisibility(View.VISIBLE);
                getEmail = login_email.getText().toString();
                getPassword = login_password.getText().toString();
                if (TextUtils.isEmpty(getEmail) || TextUtils.isEmpty(getPassword)){
                    Toast.makeText(Login.this, "Email atau Password tidak boleh kosong", Toast.LENGTH_SHORT).show();
                } else {
                    loginUserAccount();
                }
                /*startActivity(new Intent(Login.this, MainActivity.class));*/

            }

        });



        register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(Login.this, SignUp.class));

            }
        });




        forgot.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(Login.this, ForgotPassword.class));

            }
        });



    }
    @Override
    protected void onStart() {

        super.onStart();
        auth.addAuthStateListener(Listener);
    }

    @Override
    protected void onStop() {

        super.onStop();
        if (Listener != null){
            auth.removeAuthStateListener(Listener);
        }
    }
    private void loginUserAccount() {
        auth.signInWithEmailAndPassword(getEmail, getPassword).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
            @Override
            public void onComplete(@NonNull Task<AuthResult> task) {
                if (task.isSuccessful()){
                    progressBar.setVisibility(View.GONE);
                    if (auth.getCurrentUser().isEmailVerified()){
                        Toast.makeText(Login.this, "Login Successfully", Toast.LENGTH_SHORT).show();
                        Intent intent = new Intent(Login.this,listdata.class);
                        startActivity(intent);
                    } else {
                        AlertDialog.Builder alert = new AlertDialog.Builder(Login.this);
                        alert.setTitle("Periksa Email Anda Untuk Verifikasi");
                        alert.setNeutralButton("OK", new
                                DialogInterface.OnClickListener() {
                                    @Override
                                    public void onClick(DialogInterface dialog, int which){
                                        return;
                                    }
                                });
                        alert.create();
                        alert.show();
                    }
                } else {
                    progressBar.setVisibility(View.GONE);
                    Toast.makeText(Login.this,task.getException().getMessage(), Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
}